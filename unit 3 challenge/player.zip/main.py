class Player:
  def __init__(self, playerName, playedCountry, playerAge, countryFrom):
    self.playerName = playerName
    self.playedCountry = playedCountry
    self.playerAge = playerAge
    self.countryFrom = countryFrom
    
    
def countPlayers(playerList, country):
  count = 0
  
  for player in playerList:
    if player.countryFrom.lower() == country.lower():
      count += 1
      
  return count
  
  
def getPlayerPlayedForMaxCountry(playerList):
  playerList.sort(key=lambda x: len(x.playedCountry))
  return playerList[-1].playerName
  
  
if __name__ == '__main__':
  n = int(input())
  playerList = []
  
  for i in range(n):
    playerName, m = input(), int(input())
    
    playedCountry = [] 
    
    for j in range(m):
      playedCountry.append(input())
    
    playerAge, countryFrom = int(input()), input()
    
    playerList.append(Player(playerName, playedCountry, playerAge, countryFrom))
    
  country = input()
  
  noOfPlayers = countPlayers(playerList, country)
  maxPlayerName = getPlayerPlayedForMaxCountry(playerList)
  
  print(noOfPlayers)
  print(maxPlayerName)
      